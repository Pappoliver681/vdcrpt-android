#!/usr/bin/env bash
set -euo pipefail

FFMPEG_VERSION="${FFMPEG_VERSION:-8.1.2}"
ANDROID_API="${ANDROID_API:-29}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="$ROOT/src/Vdcrpt.Android/Resources/lib/arm64-v8a/libffmpeg_exec.so"
BUILD="$ROOT/.ffmpeg-build"
ICON_ICO="$BUILD/original-vdcrpt-icon.ico"
ICON_PNG="$ROOT/src/Vdcrpt.Android/Resources/drawable/vdcrpt_icon.png"

: "${ANDROID_NDK_HOME:?ANDROID_NDK_HOME must point to the Android NDK}"
HOST_TAG="linux-x86_64"
TOOLCHAIN="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/$HOST_TAG"
CC="$TOOLCHAIN/bin/aarch64-linux-android${ANDROID_API}-clang"

rm -rf "$BUILD"
mkdir -p "$BUILD"

# Use the original vdcrpt artwork from branchpanic's upstream repository.
curl -L --fail --retry 3 \
  "https://raw.githubusercontent.com/branchpanic/vdcrpt/main/src/Vdcrpt.Desktop/Assets/Icon.ico" \
  -o "$ICON_ICO"
python3 "$ROOT/scripts/ico_to_png.py" "$ICON_ICO" "$ICON_PNG"
file "$ICON_PNG"

cd "$BUILD"

curl -L --fail --retry 3 "https://ffmpeg.org/releases/ffmpeg-${FFMPEG_VERSION}.tar.xz" -o ffmpeg.tar.xz
tar -xf ffmpeg.tar.xz
cd "ffmpeg-${FFMPEG_VERSION}"

./configure \
  --target-os=android \
  --arch=aarch64 \
  --cpu=armv8-a \
  --cc="$CC" \
  --cxx="$TOOLCHAIN/bin/aarch64-linux-android${ANDROID_API}-clang++" \
  --ar="$TOOLCHAIN/bin/llvm-ar" \
  --nm="$TOOLCHAIN/bin/llvm-nm" \
  --ranlib="$TOOLCHAIN/bin/llvm-ranlib" \
  --strip="$TOOLCHAIN/bin/llvm-strip" \
  --enable-cross-compile \
  --enable-pic \
  --disable-shared \
  --enable-static \
  --disable-doc \
  --disable-debug \
  --disable-ffplay \
  --disable-ffprobe \
  --disable-network \
  --disable-avdevice \
  --disable-symver \
  --extra-cflags="-O2 -fPIE" \
  --extra-ldflags="-fPIE -pie"

make -j"$(nproc)" ffmpeg
mkdir -p "$(dirname "$OUT")"
cp ffmpeg "$OUT"
chmod +x "$OUT"
"$TOOLCHAIN/bin/llvm-strip" "$OUT" || true
file "$OUT"
