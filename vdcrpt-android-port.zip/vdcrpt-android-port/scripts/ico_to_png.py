#!/usr/bin/env python3
import struct, sys, zlib, binascii
from pathlib import Path

def png_chunk(kind: bytes, data: bytes) -> bytes:
    return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', binascii.crc32(kind + data) & 0xffffffff)

def write_png(path: Path, width: int, height: int, rgba_rows):
    raw = b''.join(b'\x00' + row for row in rgba_rows)
    png = b'\x89PNG\r\n\x1a\n'
    png += png_chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
    png += png_chunk(b'IDAT', zlib.compress(raw, 9))
    png += png_chunk(b'IEND', b'')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(png)

def convert(src: Path, dst: Path):
    data = src.read_bytes()
    if len(data) < 6:
        raise SystemExit('ICO is too small')
    reserved, typ, count = struct.unpack_from('<HHH', data, 0)
    if reserved != 0 or typ != 1 or count < 1:
        raise SystemExit('Not a Windows ICO file')

    entries = []
    off = 6
    for _ in range(count):
        w, h, colors, zero, planes, bpp, size, img_off = struct.unpack_from('<BBBBHHII', data, off)
        w = 256 if w == 0 else w
        h = 256 if h == 0 else h
        entries.append((w*h, bpp, w, h, size, img_off))
        off += 16
    _, _, nominal_w, nominal_h, size, img_off = max(entries)
    blob = data[img_off:img_off+size]

    if blob.startswith(b'\x89PNG\r\n\x1a\n'):
        dst.parent.mkdir(parents=True, exist_ok=True)
        dst.write_bytes(blob)
        return

    if len(blob) < 40:
        raise SystemExit('Unsupported ICO bitmap payload')
    hdr_size, width, stored_height, planes, bpp, compression = struct.unpack_from('<IiiHHI', blob, 0)
    if hdr_size < 40 or bpp != 32 or compression != 0:
        raise SystemExit(f'Unsupported ICO DIB: header={hdr_size}, bpp={bpp}, compression={compression}')
    width = abs(width)
    height = abs(stored_height) // 2  # ICO DIB includes XOR + AND mask heights.
    pixel_off = hdr_size
    stride = ((width * bpp + 31) // 32) * 4
    rows = []
    bottom_up = stored_height > 0
    for out_y in range(height):
        src_y = height - 1 - out_y if bottom_up else out_y
        start = pixel_off + src_y * stride
        row = blob[start:start + width * 4]
        if len(row) != width * 4:
            raise SystemExit('Truncated ICO pixel data')
        rgba = bytearray(width * 4)
        for x in range(width):
            b, g, r, a = row[x*4:x*4+4]
            rgba[x*4:x*4+4] = bytes((r, g, b, a))
        rows.append(bytes(rgba))
    write_png(dst, width, height, rows)

if __name__ == '__main__':
    if len(sys.argv) != 3:
        raise SystemExit('usage: ico_to_png.py INPUT.ico OUTPUT.png')
    convert(Path(sys.argv[1]), Path(sys.argv[2]))
