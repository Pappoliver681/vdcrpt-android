using Android.Content;
using Android.Provider;
using Vdcrpt.App;

namespace Vdcrpt.Android;

public sealed class AndroidPlatformServices(Context context) : IPlatformServices
{
    private ContentResolver Resolver => context.ContentResolver
        ?? throw new InvalidOperationException("Android ContentResolver is unavailable.");

    public string CacheDirectory => context.CacheDir?.AbsolutePath
        ?? throw new InvalidOperationException("Android cache directory is unavailable.");

    public string FfmpegExecutablePath => Path.Combine(
        context.ApplicationInfo?.NativeLibraryDir
            ?? throw new InvalidOperationException("Android native library directory is unavailable."),
        "libffmpeg_exec.so");

    public async Task<string> SaveToMoviesAsync(string cachedFilePath, string displayName)
    {
        var values = new ContentValues();
        values.Put(MediaStore.IMediaColumns.DisplayName, displayName);
        values.Put(MediaStore.IMediaColumns.MimeType, "video/mp4");
        values.Put(MediaStore.IMediaColumns.RelativePath, "Movies/vdcrpt");

        var collection = MediaStore.Video.Media.GetContentUri(MediaStore.VolumeExternalPrimary)
            ?? throw new IOException("Could not resolve the Android Movies collection.");
        var uri = Resolver.Insert(collection, values)
            ?? throw new IOException("Could not create the output video in MediaStore.");

        await using var input = System.IO.File.OpenRead(cachedFilePath);
        await using var output = Resolver.OpenOutputStream(uri)
            ?? throw new IOException("Could not open the output video for writing.");
        await input.CopyToAsync(output);
        return uri.ToString() ?? throw new IOException("Could not resolve the saved video URI.");
    }

    public Task OpenUriAsync(string uri)
    {
        var parsed = global::Android.Net.Uri.Parse(uri)
            ?? throw new ArgumentException("Invalid Android URI.", nameof(uri));
        var intent = new Intent(Intent.ActionView);
        intent.SetDataAndType(parsed, "video/mp4");
        intent.AddFlags(ActivityFlags.NewTask | ActivityFlags.GrantReadUriPermission);

        var chooser = Intent.CreateChooser(intent, "Open video")
            ?? throw new InvalidOperationException("Could not create the Android app chooser.");
        chooser.AddFlags(ActivityFlags.NewTask);
        context.StartActivity(chooser);
        return Task.CompletedTask;
    }

    public Task OpenUrlAsync(string url)
    {
        var parsed = global::Android.Net.Uri.Parse(url)
            ?? throw new ArgumentException("Invalid URL.", nameof(url));
        var intent = new Intent(Intent.ActionView, parsed);
        intent.AddFlags(ActivityFlags.NewTask);
        context.StartActivity(intent);
        return Task.CompletedTask;
    }

    public void Exit()
    {
        if (context is Activity activity) activity.FinishAndRemoveTask();
        else global::Android.OS.Process.KillProcess(global::Android.OS.Process.MyPid());
    }
}
