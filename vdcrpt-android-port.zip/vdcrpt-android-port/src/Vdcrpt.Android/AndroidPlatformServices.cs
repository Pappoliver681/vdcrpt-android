using Android.Content;
using Android.Provider;
using Vdcrpt.App;

namespace Vdcrpt.Android;

public sealed class AndroidPlatformServices(Context context) : IPlatformServices
{
    public string CacheDirectory => context.CacheDir?.AbsolutePath
        ?? throw new InvalidOperationException("Android cache directory is unavailable.");

    public string FfmpegExecutablePath => Path.Combine(
        context.ApplicationInfo?.NativeLibraryDir
            ?? throw new InvalidOperationException("Android native library directory is unavailable."),
        "libffmpeg_exec.so");

    public async Task<string> SaveToMoviesAsync(string cachedFilePath, string displayName)
    {
        var values = new ContentValues();
        values.Put(MediaStore.IMediaColumns.DisplayName, displayName);
        values.Put(MediaStore.IMediaColumns.MimeType, "video/mp4");
        values.Put(MediaStore.IMediaColumns.RelativePath, "Movies/vdcrpt");

        var collection = MediaStore.Video.Media.GetContentUri(MediaStore.VolumeExternalPrimary);
        var uri = context.ContentResolver?.Insert(collection, values)
            ?? throw new IOException("Could not create the output video in MediaStore.");

        await using var input = System.IO.File.OpenRead(cachedFilePath);
        await using var output = context.ContentResolver!.OpenOutputStream(uri)
            ?? throw new IOException("Could not open the output video for writing.");
        await input.CopyToAsync(output);
        return uri.ToString() ?? throw new IOException("Could not resolve the saved video URI.");
    }

    public Task OpenUriAsync(string uri)
    {
        var intent = new Intent(Intent.ActionView);
        var parsed = global::Android.Net.Uri.Parse(uri);
        intent.SetDataAndType(parsed, "video/mp4");
        intent.AddFlags(ActivityFlags.NewTask | ActivityFlags.GrantReadUriPermission);
        context.StartActivity(Intent.CreateChooser(intent, "Open video").AddFlags(ActivityFlags.NewTask));
        return Task.CompletedTask;
    }

    public Task OpenUrlAsync(string url)
    {
        var intent = new Intent(Intent.ActionView, global::Android.Net.Uri.Parse(url));
        intent.AddFlags(ActivityFlags.NewTask);
        context.StartActivity(intent);
        return Task.CompletedTask;
    }

    public void Exit()
    {
        if (context is Activity activity) activity.FinishAndRemoveTask();
        else global::Android.OS.Process.KillProcess(global::Android.OS.Process.MyPid());
    }
}
