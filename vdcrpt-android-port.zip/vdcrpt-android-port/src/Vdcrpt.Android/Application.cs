using Android.App;
using Android.Runtime;
using Avalonia;
using Avalonia.Android;
using Vdcrpt.App;

namespace Vdcrpt.Android;

[Application]
public class Application : AvaloniaAndroidApplication<App>
{
    protected Application(nint javaReference, JniHandleOwnership transfer) : base(javaReference, transfer) { }

    protected override AppBuilder CustomizeAppBuilder(AppBuilder builder)
    {
        PlatformServices.Current = new AndroidPlatformServices(this);
        return base.CustomizeAppBuilder(builder).WithInterFont();
    }
}
