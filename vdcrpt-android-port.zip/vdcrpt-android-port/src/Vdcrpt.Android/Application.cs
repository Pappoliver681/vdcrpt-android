using Android.App;
using Android.Runtime;
using Avalonia;
using Avalonia.Android;

namespace Vdcrpt.Android;

[Application]
public class AndroidApp : AvaloniaAndroidApplication<global::Vdcrpt.App.App>
{
    protected AndroidApp(nint javaReference, JniHandleOwnership transfer) : base(javaReference, transfer) { }

    protected override AppBuilder CustomizeAppBuilder(AppBuilder builder)
    {
        PlatformServices.Current = new AndroidPlatformServices(this);
        return base.CustomizeAppBuilder(builder).WithInterFont();
    }
}
