using Android.App;
using Android.Content.PM;
using Avalonia.Android;

namespace Vdcrpt.Android;

[Activity(
    Label = "vdcrpt",
    Theme = "@style/MyTheme.NoActionBar",
    Icon = "@drawable/vdcrpt_icon",
    MainLauncher = true,
    Exported = true,
    ConfigurationChanges = ConfigChanges.Orientation | ConfigChanges.ScreenSize | ConfigChanges.UiMode)]
public class MainActivity : AvaloniaMainActivity
{
}
