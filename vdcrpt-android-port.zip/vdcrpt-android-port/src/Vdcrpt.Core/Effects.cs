using System;
using System.Collections.Generic;
using System.IO;

namespace Vdcrpt.Core;

// Ported from branchpanic/vdcrpt (MIT). The byte-mangling behavior is intentionally kept intact.
public static class Effects
{
    private static readonly Random EffectRandom = new();

    public static Action<List<byte>> Repeat(int iterations, int chunkSize, int minRepetitions, int maxRepetitions)
    {
        return data =>
        {
            if (data.Count <= 64)
                throw new InvalidDataException("The intermediate AVI is too small to corrupt.");

            if (chunkSize < 1)
                throw new ArgumentOutOfRangeException(nameof(chunkSize));

            var maxStart = data.Count - Math.Min(chunkSize, data.Count - 33);
            if (maxStart <= 32)
                throw new InvalidDataException("Burst size is too large for this video.");

            var bytes = data.ToArray();
            var repetitions = new int[iterations];

            if (minRepetitions == maxRepetitions)
            {
                Array.Fill(repetitions, minRepetitions);
            }
            else
            {
                for (var i = 0; i < iterations; i++)
                    repetitions[i] = EffectRandom.Next(minRepetitions, maxRepetitions + 1);
            }

            var positions = new int[iterations];
            for (var i = 0; i < iterations; i++)
                positions[i] = EffectRandom.Next(32, maxStart);

            Array.Sort(positions);

            using var stream = new MemoryStream();
            using var writer = new BinaryWriter(stream);
            var lastEnd = 0;

            for (var i = 0; i < positions.Length; i++)
            {
                var pos = positions[i];
                writer.Write(bytes, lastEnd, pos - lastEnd);
                for (var j = 0; j < repetitions[i]; j++)
                    writer.Write(bytes, pos, Math.Min(chunkSize, bytes.Length - pos));
                lastEnd = pos;
            }

            writer.Write(bytes, lastEnd, data.Count - lastEnd);
            data.Clear();
            data.AddRange(stream.ToArray());
        };
    }
}
