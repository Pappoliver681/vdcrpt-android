using System.Collections.Generic;

namespace Vdcrpt.Core;

public sealed class VideoProcessor(ProcessFfmpegService ffmpeg, string cacheDirectory)
{
    public async Task CorruptAsync(
        string inputPath,
        string outputPath,
        CorruptionSettings settings,
        IProgress<(int Percent, string Message)>? progress = null,
        CancellationToken cancellationToken = default)
    {
        Directory.CreateDirectory(cacheDirectory);
        var token = Guid.NewGuid().ToString("N");
        var cleanAvi = Path.Combine(cacheDirectory, $"vdcrpt_{token}_clean.avi");
        var brokenAvi = Path.Combine(cacheDirectory, $"vdcrpt_{token}_broken.avi");

        try
        {
            progress?.Report((20, "Loading video..."));
            await ffmpeg.RunAsync(new[]
            {
                "-hide_banner", "-loglevel", "error", "-y",
                "-i", inputPath,
                "-c:v", "mpeg4",
                "-c:a", "pcm_mulaw",
                "-f", "avi",
                cleanAvi
            }, cancellationToken);

            progress?.Report((50, "Corrupting data..."));
            var data = new List<byte>(await File.ReadAllBytesAsync(cleanAvi, cancellationToken));
            Effects.Repeat(
                settings.Iterations,
                settings.BurstSize,
                settings.MinTrailLength,
                settings.UseTrailLengthRange ? settings.MaxTrailLength : settings.MinTrailLength)(data);
            await File.WriteAllBytesAsync(brokenAvi, data.ToArray(), cancellationToken);

            progress?.Report((75, "Rendering corrupted video..."));
            await ffmpeg.RunAsync(new[]
            {
                "-hide_banner", "-loglevel", "error", "-y",
                "-fflags", "+genpts",
                "-i", brokenAvi,
                "-map_metadata", "-1",
                "-c:v", "mpeg4",
                "-q:v", "5",
                "-c:a", "aac",
                "-movflags", "+faststart",
                outputPath
            }, cancellationToken);

            progress?.Report((100, "Finishing up..."));
        }
        finally
        {
            TryDelete(cleanAvi);
            TryDelete(brokenAvi);
        }
    }

    private static void TryDelete(string path)
    {
        try { if (File.Exists(path)) File.Delete(path); } catch { }
    }
}
