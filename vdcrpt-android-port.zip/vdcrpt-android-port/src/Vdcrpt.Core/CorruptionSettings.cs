namespace Vdcrpt.Core;

public sealed record CorruptionSettings(
    int BurstSize,
    int Iterations,
    int MinTrailLength,
    int MaxTrailLength,
    bool UseTrailLengthRange);
