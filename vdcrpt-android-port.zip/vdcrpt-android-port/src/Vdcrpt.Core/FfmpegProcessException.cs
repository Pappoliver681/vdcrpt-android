namespace Vdcrpt.Core;

public sealed class FfmpegProcessException(string message, int exitCode, string stderr)
    : Exception(message)
{
    public int ExitCode { get; } = exitCode;
    public string StandardError { get; } = stderr;
}
