using System.Diagnostics;
using System.Text;

namespace Vdcrpt.Core;

public sealed class ProcessFfmpegService(string executablePath)
{
    public async Task RunAsync(IEnumerable<string> arguments, CancellationToken cancellationToken = default)
    {
        var startInfo = new ProcessStartInfo
        {
            FileName = executablePath,
            UseShellExecute = false,
            RedirectStandardError = true,
            RedirectStandardOutput = true,
            CreateNoWindow = true,
        };

        foreach (var argument in arguments)
            startInfo.ArgumentList.Add(argument);

        using var process = new Process { StartInfo = startInfo };
        var stderr = new StringBuilder();
        process.ErrorDataReceived += (_, e) =>
        {
            if (e.Data is not null) stderr.AppendLine(e.Data);
        };

        if (!process.Start())
            throw new FfmpegProcessException("FFmpeg could not be started.", -1, string.Empty);

        process.BeginErrorReadLine();
        await process.WaitForExitAsync(cancellationToken);

        if (process.ExitCode != 0)
            throw new FfmpegProcessException($"FFmpeg exited with code {process.ExitCode}.", process.ExitCode, stderr.ToString());
    }
}
