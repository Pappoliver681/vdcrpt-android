using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Platform.Storage;

namespace Vdcrpt.App;

public partial class MainView : UserControl
{
    private static readonly FilePickerFileType Videos = new("Video files")
    {
        Patterns = new[] { "*.mp4", "*.mkv", "*.mov", "*.avi", "*.webm", "*.m4v", "*.3gp", "*.mpeg", "*.mpg" },
        MimeTypes = new[] { "video/*" }
    };

    private static readonly FilePickerFileType Mp4 = new("MP4 video")
    {
        Patterns = new[] { "*.mp4" },
        MimeTypes = new[] { "video/mp4" }
    };

    public MainView() => InitializeComponent();

    private MainViewModel? Vm => DataContext as MainViewModel;

    private async void OnOpenPressed(object? sender, RoutedEventArgs e)
    {
        var top = TopLevel.GetTopLevel(this);
        if (top is null || Vm is null) return;

        var files = await top.StorageProvider.OpenFilePickerAsync(new FilePickerOpenOptions
        {
            Title = "Open video",
            AllowMultiple = false,
            FileTypeFilter = new[] { Videos }
        });

        var picked = files.FirstOrDefault();
        if (picked is null) return;

        var ext = Path.GetExtension(picked.Name);
        var localPath = Path.Combine(PlatformServices.Required.CacheDirectory, $"vdcrpt_input_{Guid.NewGuid():N}{ext}");
        await using var input = await picked.OpenReadAsync();
        await using var output = File.Create(localPath);
        await input.CopyToAsync(output);
        Vm.SetInput(localPath, picked.Name);
    }

    private async void OnCorruptPressed(object? sender, RoutedEventArgs e)
    {
        var top = TopLevel.GetTopLevel(this);
        if (top is null || Vm is null) return;

        IStorageFile? destination = null;
        var suggestedName = Vm.SuggestedOutputName();

        if (Vm.AskForFilename)
        {
            destination = await top.StorageProvider.SaveFilePickerAsync(new FilePickerSaveOptions
            {
                Title = "Save corrupted video",
                SuggestedFileName = suggestedName,
                DefaultExtension = "mp4",
                FileTypeChoices = new[] { Mp4 }
            });
            if (destination is null) return;
        }

        var cachedOutput = await Vm.CorruptToCacheAsync();
        if (cachedOutput is null) return;

        string resultUri;
        if (destination is not null)
        {
            await using var source = File.OpenRead(cachedOutput);
            await using var target = await destination.OpenWriteAsync();
            if (target.CanSeek) target.SetLength(0);
            await source.CopyToAsync(target);
            resultUri = destination.Path.ToString();
        }
        else
        {
            resultUri = await PlatformServices.Required.SaveToMoviesAsync(cachedOutput, suggestedName);
        }

        try { File.Delete(cachedOutput); } catch { }
        Vm.SetResult(resultUri);
        if (Vm.OpenWhenComplete) await PlatformServices.Required.OpenUriAsync(resultUri);
    }

    private async void OnOpenResultPressed(object? sender, RoutedEventArgs e)
    {
        if (Vm?.ResultUri is { Length: > 0 } uri)
            await PlatformServices.Required.OpenUriAsync(uri);
    }

    private void OnExitPressed(object? sender, RoutedEventArgs e) => PlatformServices.Required.Exit();
    private async void OnItchPressed(object? sender, RoutedEventArgs e) => await PlatformServices.Required.OpenUrlAsync("https://branchpanic.itch.io/vdcrpt");
    private async void OnGitHubPressed(object? sender, RoutedEventArgs e) => await PlatformServices.Required.OpenUrlAsync("https://github.com/branchpanic/vdcrpt");
}
