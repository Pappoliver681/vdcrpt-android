using System.ComponentModel;
using System.Runtime.CompilerServices;
using Vdcrpt.Core;

namespace Vdcrpt.App;

public sealed class MainViewModel : INotifyPropertyChanged
{
    private string _inputPath = string.Empty;
    private string _inputDisplayName = string.Empty;
    private Preset _currentPreset;
    private int _burstSize = 3000;
    private int _iterations = 400;
    private int _minTrailLength = 8;
    private int _maxTrailLength = 8;
    private bool _useTrailLengthRange;
    private bool _openWhenComplete;
    private bool _askForFilename = true;
    private bool _isBusy;
    private int _progressAmount;
    private string _progressMessage = "Ready!";
    private string? _resultUri;

    public MainViewModel() => _currentPreset = CurrentPreset = Presets[0];

    public List<Preset> Presets { get; } = Preset.DefaultPresets;
    public string VersionText => "Android port • Avalonia 12.1.1";
    public string InputPath { get => _inputPath; private set { _inputPath = value; OnPropertyChanged(); OnPropertyChanged(nameof(CanStartCorrupting)); } }
    public string InputDisplayName { get => _inputDisplayName; private set { _inputDisplayName = value; OnPropertyChanged(); } }
    public int BurstSize { get => _burstSize; set { _burstSize = Math.Max(1, value); OnPropertyChanged(); } }
    public int Iterations { get => _iterations; set { _iterations = Math.Max(1, value); OnPropertyChanged(); } }
    public int MinTrailLength { get => _minTrailLength; set { _minTrailLength = Math.Max(1, value); if (_maxTrailLength < _minTrailLength) _maxTrailLength = _minTrailLength; OnPropertyChanged(); OnPropertyChanged(nameof(MaxTrailLength)); } }
    public int MaxTrailLength { get => _maxTrailLength; set { _maxTrailLength = Math.Max(1, value); if (_minTrailLength > _maxTrailLength) _minTrailLength = _maxTrailLength; OnPropertyChanged(); OnPropertyChanged(nameof(MinTrailLength)); } }
    public bool UseTrailLengthRange { get => _useTrailLengthRange; set { _useTrailLengthRange = value; OnPropertyChanged(); } }
    public bool OpenWhenComplete { get => _openWhenComplete; set { _openWhenComplete = value; OnPropertyChanged(); } }
    public bool AskForFilename { get => _askForFilename; set { _askForFilename = value; OnPropertyChanged(); } }
    public bool IsBusy { get => _isBusy; private set { _isBusy = value; OnPropertyChanged(); OnPropertyChanged(nameof(CanStartCorrupting)); } }
    public int ProgressAmount { get => _progressAmount; private set { _progressAmount = value; OnPropertyChanged(); } }
    public string ProgressMessage { get => _progressMessage; private set { _progressMessage = value; OnPropertyChanged(); } }
    public bool CanStartCorrupting => File.Exists(InputPath) && !IsBusy;
    public string? ResultUri { get => _resultUri; private set { _resultUri = value; OnPropertyChanged(); OnPropertyChanged(nameof(HasResult)); } }
    public bool HasResult => !string.IsNullOrWhiteSpace(ResultUri);

    public Preset CurrentPreset
    {
        get => _currentPreset;
        set
        {
            _currentPreset = value;
            BurstSize = value.BurstSize;
            MinTrailLength = value.MinBurstLength;
            UseTrailLengthRange = value.UseLengthRange;
            MaxTrailLength = value.UseLengthRange ? value.MaxBurstLength : value.MinBurstLength;
            Iterations = value.Iterations;
            OnPropertyChanged();
        }
    }

    public void SetInput(string cachePath, string displayName)
    {
        InputPath = cachePath;
        InputDisplayName = displayName;
        ProgressMessage = "Ready!";
    }

    public string SuggestedOutputName()
    {
        var baseName = Path.GetFileNameWithoutExtension(InputDisplayName);
        if (string.IsNullOrWhiteSpace(baseName)) baseName = "video";
        return $"{baseName}_vdcrpt_{DateTime.Now:yyyyMMdd_HHmmss}.mp4";
    }

    public async Task<string?> CorruptToCacheAsync(CancellationToken cancellationToken = default)
    {
        if (!CanStartCorrupting) return null;

        IsBusy = true;
        ResultUri = null;
        ProgressAmount = 0;

        try
        {
            var platform = PlatformServices.Required;
            var cachedOutput = Path.Combine(platform.CacheDirectory, $"vdcrpt_out_{Guid.NewGuid():N}.mp4");
            var processor = new VideoProcessor(new ProcessFfmpegService(platform.FfmpegExecutablePath), platform.CacheDirectory);
            var progress = new Progress<(int Percent, string Message)>(p =>
            {
                ProgressAmount = p.Percent;
                ProgressMessage = p.Message;
            });

            await processor.CorruptAsync(InputPath, cachedOutput,
                new CorruptionSettings(BurstSize, Iterations, MinTrailLength, MaxTrailLength, UseTrailLengthRange),
                progress, cancellationToken);
            return cachedOutput;
        }
        catch (Exception ex)
        {
            ProgressMessage = ex is FfmpegProcessException
                ? "The video failed to render. Try lower settings or another video."
                : $"Error: {ex.Message}";
            return null;
        }
        finally
        {
            ProgressAmount = 0;
            IsBusy = false;
        }
    }

    public void SetResult(string uri)
    {
        ResultUri = uri;
        ProgressMessage = "Done!";
    }

    public event PropertyChangedEventHandler? PropertyChanged;
    private void OnPropertyChanged([CallerMemberName] string? name = null) => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
}
