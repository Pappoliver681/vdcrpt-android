namespace Vdcrpt.App;

public sealed class Preset
{
    public string Name { get; init; } = string.Empty;
    public int BurstSize { get; init; }
    public int Iterations { get; init; }
    public bool UseLengthRange { get; init; }
    public int MinBurstLength { get; init; }
    public int MaxBurstLength { get; init; }

    public static List<Preset> DefaultPresets => new()
    {
        new() { Name = "Melting Chaos", BurstSize = 3000, MinBurstLength = 8, Iterations = 400 },
        new() { Name = "Jittery", BurstSize = 20000, MinBurstLength = 1, MaxBurstLength = 8, UseLengthRange = true, Iterations = 200 },
        new() { Name = "Source Engine", BurstSize = 45000, MinBurstLength = 2, MaxBurstLength = 6, UseLengthRange = true, Iterations = 60 },
        new() { Name = "Subtle", BurstSize = 200, MinBurstLength = 2, Iterations = 60 },
        new() { Name = "Many Artifacts", BurstSize = 500, MinBurstLength = 3, Iterations = 2000 },
        new() { Name = "Trash (unstable, breaks audio)", BurstSize = 1, MinBurstLength = 1, Iterations = 10000 },
        new() { Name = "Legacy", BurstSize = 1000, MinBurstLength = 10, MaxBurstLength = 90, UseLengthRange = true, Iterations = 50 },
    };
}
