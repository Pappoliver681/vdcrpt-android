namespace Vdcrpt.App;

public interface IPlatformServices
{
    string CacheDirectory { get; }
    string FfmpegExecutablePath { get; }
    Task<string> SaveToMoviesAsync(string cachedFilePath, string displayName);
    Task OpenUriAsync(string uri);
    Task OpenUrlAsync(string url);
    void Exit();
}

public static class PlatformServices
{
    public static IPlatformServices? Current { get; set; }

    public static IPlatformServices Required => Current
        ?? throw new InvalidOperationException("Platform services have not been initialized.");
}
