# vdcrpt Android port

Unofficial Android port scaffold of **branchpanic/vdcrpt**, preserving its byte-corruption effect and its desktop-style Avalonia UI as closely as practical on a phone.

## What is already ported

- Original vdcrpt `Effects.Repeat` corruption behavior and original presets.
- Desktop-style layout (File / Help menu, Video, Preset, Burst Size, Burst Length, Iterations, checkboxes, Corrupt/Open Result, progress).
- Android file picker and save picker via Avalonia `StorageProvider`.
- Automatic save to `Movies/vdcrpt` when **Ask where to save every time** is disabled.
- Android 10+ scoped-storage-safe workflow: picked input is copied into app cache; FFmpeg operates only on app-local paths; final output is streamed back to the chosen document or MediaStore.
- A non-template custom launcher icon (no default blue tile icon).
- ARM64 FFmpeg executable compiled inside GitHub Actions and embedded in the APK's native library directory.
- GitHub Actions workflow that uploads an APK artifact.

## Fidelity note

The corruption step is the original vdcrpt byte-repeat algorithm. Like desktop vdcrpt, the video is first transcoded to MPEG-4 video + mu-law PCM in an AVI container, corrupted as raw bytes, and then re-rendered. The Android output uses FFmpeg's built-in `mpeg4` encoder instead of desktop vdcrpt's `libx264` default so the APK can build FFmpeg without bundling an additional x264 library.

## Build

The workflow is the easiest path: push to GitHub, open **Actions → Build Android APK → Run workflow**, then download the `vdcrpt-android-arm64` artifact.

Local build requires .NET 10, the Android workload, Android SDK/NDK, and a built `libffmpeg_exec.so` in `src/Vdcrpt.Android/Resources/lib/arm64-v8a/`.

## Status

This is the first Android port pass and has not yet been device-tested in this environment. The next step is to run the GitHub Actions build, install the generated APK on an ARM64 Android phone, and fix any compile/runtime issues from real Android execution.
